<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
<!-- <style>
.container{ min-height:70vh}
</style> -->

    <title>Hello, world!</title>
  </head>
  <body>
  <?php include 'dbconnect.php';?>
  <!-- '.$_SERVER["REQUEST_URI"].' -->
  <?php
    include 'header.php'; 


?>
 <?php 
    if(isset($_SESSION['loggedin']) && $_SESSION['loggedin']==true){ 
   
   echo '<div  id="container" class="container my-5">
      <h1 class="text-center">Contact Us</h1>
      <form method="POST" action="'. $_SERVER["REQUEST_URI"] .'">
      <div class="form-row">
        <div class="form-group col-md-6">
          <label for="name">Name</label>
          <input type="text" class="form-control" name="name" id="name">
        </div>
  
        <div class="form-group col-md-6">
          <label for="email">Email</label>
          <input type="email" class="form-control" name="email" id="email">
        </div>
        </div>
  
      <div class="form-group">
        <label for="query">Your query</label>
        <textarea class="form-control" name="query" id="query"></textarea>
      </div>
  
      <div class="form-group">
        <label for="address">Address </label>
        <input type="text" class="form-control" name="address" id="address" placeholder=" Ex :- Main St ,Apartment, studio, or floor">
      </div>
  
      <div class="form-row">
        <div class="form-group col-md-6">
          <label for="inputCity">City</label>
          <input type="text" class="form-control"  name="city" id="inputCity">
        </div>
       
        <div class="form-group col-md-2">
          <label for="inputZip">Zip code</label>
          <input type="text" class="form-control"  name="zip" id="inputZip">
        </div>
      </div>
      <div class="form-group">
        <div class="form-check">
          <input class="form-check-input" type="checkbox" id="gridCheck">
          <label class="form-check-label" for="gridCheck">
            Check me out
          </label>
        </div>
      </div>
      <button type="submit" class="btn btn-success">Submit</button>
      
    </form>


      </div>';
  
   } ?>
<?php
$method=$_SERVER['REQUEST_METHOD'];
 if($method=='POST'){
   $name=$_POST['name'];
   $email=$_POST['email'];
   $city=$_POST['city'];
   $address=$_POST['address'];
   $query=$_POST['query'];
   $zip=$_POST['zip'];
   $sql="INSERT INTO `contact` (`name`, `email`, `address`, `city`, `query`, `zip`) VALUES ('$name', '$email', '$address', '$city', '$query', '$zip')";
   $result=mysqli_query($conn,$sql);
   if($result)
   {
      echo ' <div class="alert alert-success alert-dismissible fade show my-0" role="alert">
       <strong>Success! </strong> your query has been successfully submitted
       <button type="button" class="close " data-dismiss="alert" aria-label="Close">
         <span aria-hidden="true">&times;</span>
       </button>
     </div>';
    
   }
   }
?> 
    <?php include 'footer.php';
?>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  </body>
</html>