<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

    <title>Aboutus</title>
    
  </head>
  <body>
  <?php include 'dbconnect.php';?>
  <?php
    include 'header.php'; ?>
  <h2><br></h2>
<div class="container">
  <div class="row">
  <div class = "col-sm-6">
    <div class="card">
                   <div class="card-header" >  
                     <h3 class="mb-0">
                       <a ><small>Ritik Pal</small></a>
                    </h3>
                   </div>
                 <div>
                    <div class="card-body">
                       <img src="img/profile.jpg" class="card-img" alt="...">
                       <p>Ritik pal, the  backend developer of this website  is  a student of computer science & engineering  branch  in Bundelkhand institute of engineering and technology, Jhansi .

nowadays, Ritik is working  in many fields of coding ,website development , WordPress development and many more..</b>
<b> <br>I already developed  many of websites and worked  on many of projects  of e-commerce and forum websites and  my website http://oyee.ga is one of them.</b><br>
  <br><b>Areas  we serve :--</b><br>we want to start a organization to provide the best facilities to learn coding ,website development ,
     WordPress development and many more which you want to learn . we know very well  the needs of the present and future
      so to develop our learners we provide the 
     techniques and  best facilities  to make websites  and  there  launching on web server with a full  security 
     as a student we know very well that in the starting of your carrier in development we need money  so to 
     solve your problems we comes forward  and our websites provides you all the facilities with free of cost . </p>
                     </div>
                 </div>
               </div>
             </div>



  <div class = "col-sm-6">
    <div class="card">
                   <div class="card-header" >  
                     <h3 class="mb-0">
                       <a ><small>Hari Prabhat Kushwaha</small></a>
                    </h3>
                   </div>
                 <div>
                    <div class="card-body">
                       <img src="img/hari.jpg" class="card-img" alt="...">
                       <p> Hari Prabhat Kushwaha, the  frontend developer of this website  is  a student of computer science & engineering  branch  in Bundelkhand institute of engineering and technology, Jhansi .

nowadays, Hari Prabhat is working  in many fields of coding ,website development and many more..</b>
<b> <br>I already developed  many of websites and worked  on some Projects like e-commerce website,snake game and few react projects.</b><br>
  <br><b>Areas  we serve :--</b><br>we want to start a organization to provide the best facilities to learn coding ,website development ,
     WordPress development and many more which you want to learn . we know very well  the needs of the present and future
      so to develop our learners we provide the 
     techniques and  best facilities  to make websites  and  there  launching on web server with a full  security 
     as a student we know very well that in the starting of your carrier in development we need money  so to 
     solve your problems we comes forward  and our websites provides you all the facilities with free of cost . </p>
                     </div>
                 </div>
               </div>
             </div>             
  </div>
</div>
<?php include 'footer.php';

?>



    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  </body>
</html>