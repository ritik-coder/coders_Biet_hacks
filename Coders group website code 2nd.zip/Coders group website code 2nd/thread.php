
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

    <title>thread</title>
  </head>
  <body>
  
  <?php include 'dbconnect.php';?>
  <?php
    include 'header.php'; ?>
    

    <?php
$id=$_GET['catid'];

// $user_id=$_SESSION['user_id'];

 $sql="SELECT * FROM `categories` WHERE categery_id='$id'";
$result=mysqli_query($conn,$sql);
while($row=mysqli_fetch_assoc($result)){
    $catname=$row['categery_name'];
    $catdesc=$row['categery_description'];
}
?>
 <?php
 $method=$_SERVER['REQUEST_METHOD'];
 if($method=='POST'){
  $user_id=$_SESSION['user_id'];
   $thread_name=$_POST['problem'];
   $thread_name = str_replace("<","&lt"," $thread_name ");
   $thread_name = str_replace(">","&gt"," $thread_name ");
   $thread_desc=$_POST['query'];
   $thread_desc = str_replace("<","&lt"," $thread_desc ");
   $thread_desc = str_replace(">","&gt"," $thread_desc ");
   $sql="INSERT INTO `thread` ( `thread_name`, `thread_desc`, `thread_cat_id`, `thread_user_id`) VALUES ('$thread_name', '$thread_desc', '$id', '$user_id')";
 $result=mysqli_query($conn,$sql);
 if($result){
  echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong>Success!</strong> your query has been successfully submitted waiting for someone reply.
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div> ';
 }
  }

 ?>

<!-- categories container start here -->
    <div class="container my-3">
   
  <div class="jumbotron">
  <h1 class="display-4">Welcome to <?php echo $catname ;?> Forum</h1>
  <p class="lead"> <?php echo $catdesc;?> </p>
  <hr class="my-4">
  <p><b>About Forum</b><br>
   Forum is an online discussion forum where youth or even the experienced
   professionals discuss their queries related to and get answers for their
    questions from other talented individuals. An online discussion can be 
    started by asking questions, helping others with answers.
   The best part is that it is very simple and is free of cost.    </p>
  <p><b>It is  peers to peers forum  here are some important  instruction  in this forum :</b> 
  <br>1.No Spam / Advertising / Self-promote in the forums. 
  <br>2. Do not post copyright-infringing material. 
  <br>3. Do not post “offensive” posts, links or images.</p>
  
  <a class="btn btn-success btn-lg" href="ReactLearn.php" role="button">Learn more</a>
</div>

<h1 class="display-4">Start Your Discussion</h1>
<?php 
    if(isset($_SESSION['loggedin']) && $_SESSION['loggedin']==true){

echo '<div class="container">
<form method="POST" action ="'. $_SERVER["REQUEST_URI"] .'"
  // <div class="form-group row col-12">
    <label for="problem">Problem title</label>
    <input type="text" class="form-control" id="problem" name="problem" >
   
  </div>
  
  <div class="form-group row col-12 ml-1">
    <label for="query">Enter your query</label>
    <textarea class="form-control" id="query" name="query"></textarea>
  </div>
 
  <button type="submit" class="btn btn-success ml-3">Submit</button>
</form>
</div>';
    }
    else{  echo ' <div class="alert alert-warning alert-dismissible fade show my-0" role="alert">
      <strong>Opps!</strong> Now you are not loggedin please loggedin for disscution.
      <button type="button" class="close " data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>';}
?> 


<div class="container">
<h1>Browse questions</h1>

<?php
$id=$_GET['catid'];
$sql="SELECT * FROM `thread` WHERE thread_cat_id='$id'";
$result=mysqli_query($conn,$sql);
$noresult =true;
while($row=mysqli_fetch_assoc($result)){
  $noresult =false;
  $thread_id=$row['thread_id'];
  $thread_title=$row['thread_name'];
  $thread_desc=$row['thread_desc'];
  $user_id=$row['thread_user_id'];
  
  $sql2="SELECT * FROM `user` WHERE `user_id`= '$user_id'";
  $result2=mysqli_query($conn,$sql2);
  $row2=mysqli_fetch_assoc($result2);
  $email=$row2['email'];
 echo'<div class="media my-3">
  <img src="img/userdefault.png" width="45px" class="mr-3" alt="...">
  <div class="media-body">
    <h5 class="mt-0"> <a href="threadans.php?threadid='.$thread_id .'">'. $thread_title .'</a></h5>
     '. $thread_desc .'
    <p><b> Posted by '. $email .'</b></p>
    
     
  </div>
   </div>';
}
if($noresult){echo '<div class="jumbotron jumbotron-fluid">
  <div class="container">
    <h1 class="display-4">Sorry</h1>
    <p class="lead">Be the first person to have an query</p>
  </div>
</div>';}
?>

</div>



  
</div>
    <?php include 'footer.php';

?>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  </body>
</html>