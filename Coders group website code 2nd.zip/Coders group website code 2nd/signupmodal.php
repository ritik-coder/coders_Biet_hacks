<div class="modal fade" id="signupModal" tabindex="-1" role="dialog" aria-labelledby="signupModalLabel"
    aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="signupModalLabel">sign up for forum</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
                <form method="POST" action="signup.php">
            <div class="modal-body">
                    <div class="form-group">
                        <input type="text" class="form-control" id="name" placeholder="Name" name="name">
                    </div>

                    <div class="form-group">
                        <input type="number" class="form-control" id="contact" placeholder="contact" name="contact">
                    </div>
                    <div class="form-group">
                        <input type="email" class="form-control" id="Email" placeholder="E-mail" name="email" aria-describedby="emailHelp">
                        <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone
                            else.</small>
                    </div>

                    <div class="form-group">
                        <input type="password" class="form-control" id="Password" placeholder="Password" name="password">
                    </div>

                    <div class="form-group">            
                        <input type="password" class="form-control" id="CPassword" placeholder="confirm password" name="Cpassword">
                    </div>

                    <button type="submit" class="btn btn-success">Submit</button>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                
            </div>
        </div>
                </form>
    </div>
</div>