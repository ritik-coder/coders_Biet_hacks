<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

    <title>threadans</title>
  </head>
  <body>
  <?php include 'dbconnect.php';?>
  <?php
    include 'header.php'; ?>
    <?php
    $id=$_GET['threadid'];
 $method=$_SERVER['REQUEST_METHOD'];
 if($method=='POST'){
   $thread_desc=$_POST['comment'];
   
$thread_desc = str_replace("<","&lt"," $thread_desc ");
$thread_desc = str_replace(">","&gt"," $thread_desc ");
   $sno=$_POST['sno'];
$sql="INSERT INTO `comments` ( `comment_desc`, `thread_id`, `comment_by`) VALUES (' $thread_desc ', ' $id ', ' $sno')";
 $result=mysqli_query($conn,$sql);
 if($result){
  echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong>Success!</strong> your comment has been successfully added
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div> ';
 }
  }

 ?>
    <?php
$id=$_GET['threadid'];
 $sql="SELECT * FROM `thread` WHERE thread_id='$id'";
$result=mysqli_query($conn,$sql);
while($row=mysqli_fetch_assoc($result)){
    $thread_name=$row['thread_name'];
    $thread_desc=$row['thread_desc'];
    $thread_user_id=$row['thread_user_id'];

    $sql3="SELECT * FROM `user` WHERE `user_id`= '$thread_user_id'";
    $result3=mysqli_query($conn,$sql3);
    $row3=mysqli_fetch_assoc($result3);
    $email=$row3['email'];

}
?>
<!-- categories container start here -->
    <div class="container my-3">
   
  <div class="jumbotron">
  <h1 class="display-4"> <?php echo $thread_name ;?> </h1>
  <p class="lead"> <?php echo $thread_desc;?> </p>
  <hr class="my-4">
  <p><b>It is  peers to peers forum  here are some important  instruction  in this forum : </b>
  <br>1.No Spam / Advertising / Self-promote in the forums. 
  <br>2. Do not post copyright-infringing material. 
  <br>3. Do not post “offensive” posts, links or images.</p>
  <b>posted by :<?php echo "  $email "; ?></b>
  <!-- <a class="btn btn-success btn-lg" href="#" role="button">Learn more</a> -->
</div>

<?php
  if(isset($_SESSION['loggedin']) && $_SESSION['loggedin']==true){  
echo '<div class="container">
<form method="POST" action ="'.$_SERVER['REQUEST_URI'].'">
  
  <div class="form-group">
    <label for="query">Enter your comment</label>
    <textarea class="form-control" id="comment" name="comment" rows="3"></textarea>
    <input type="hidden" name="sno" value=" '. $_SESSION['user_id'] .'">
  </div>
 
  <button type="submit" class="btn btn-success">Post your comment</button>
</form>
</div> ';
  }
  else{  echo ' <div class="alert alert-warning alert-dismissible fade show my-0" role="alert">
    <strong>Opps!</strong> Now you are not loggedin please loggedin for comments .
    <button type="button" class="close " data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>';}
?>



<div class="container">
<h1>Comments</h1>

<?php

$sql="SELECT * FROM `comments` WHERE thread_id='$id'";
$result=mysqli_query($conn,$sql);
$noresult =true;
while($row=mysqli_fetch_assoc($result)){
  $noresult =false;
 $comment_desc=$row['comment_desc'];
 $user_id=$row['comment_by'];
 $sql2="SELECT * FROM `user` WHERE `user_id`= '$user_id'";
 $result2=mysqli_query($conn,$sql2);
 $row2=mysqli_fetch_assoc($result2);
 $email=$row2['email'];
 
 echo'<div class="media my-3">
  <img src="img/userdefault.png" width="45px" class="mr-3" alt="...">
  <div class="media-body">
     <p>'. $comment_desc .'</p>
    comment by <b>'. $email.'</b>
     </div>
   </div>';
}
if($noresult){echo '<div class="jumbotron jumbotron-fluid">
  <div class="container">
    <h1 class="display-4">Sorry</h1>
    <p class="lead">Be the first person to have an comment</p>
  </div>
</div>';}
?> 

</div>



  
</div>
    <?php include 'footer.php';

?>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  </body>
</html>