<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
     <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="styles.css">

    <title>Developers Forum</title>
  </head>
  <body style="margin-bottom:100px; margin-top:50px;">
  <?php include 'dbconnect.php';?>
  <?php
    include 'header.php'; ?>
    



  <div class="container">
    <div class="row row-content">
       <div class="col-12 card">
                    <h2>Some Important Sources For React</h2>
                        <h4>1). <a href="https://reactjs.org/">Official React Page</a></h4>
                        <h4>2). <a href="https://www.tutorialspoint.com/reactjs/reactjs_state.htm">React State</a></h4>
                        <h4>3). <a href="https://www.valentinog.com/blog/hooks/">React Hooks</a></h4>
                        <h4>4). <a href="https://www.geeksforgeeks.org/reactjs-fragments/">React Fragments</a></h4>
                        <h4>5). <a href="https://www.npmjs.com/package/react-redux">React Redux</a></h4>
                </div>
    </div>
  </div>
  <div class="container">
    <div class="row row-content">
       <div class="col-12 card">
                    <h2>Some Important Sources For C++</h2>
                        <h4>1). <a href="en.wikipedia.org/wiki/C%2B%2B">About C++</a></h4>
                        <h4>2). <a href="https://www.tutorialspoint.com/cplusplus/index.htm">Programming Introduction</a></h4>
                        <h4>3). <a href="https://www.javatpoint.com/cpp-oops-concepts">C++ OOPs</a></h4>
                        <h4>4). <a href="https://www.w3schools.com/cpp/cpp_operators.asp">C++ Operators</a></h4>
                        <h4>5). <a href="https://www.programiz.com/cpp-programming/function">C++ Functions</a></h4>
                </div>
    </div>
  </div>
  <div class="container">
    <div class="row row-content">
       <div class="col-12 card">
                    <h2>Some Important Sources For Django</h2>
                        <h4>1). <a href="https://www.djangoproject.com/">Official Page</a></h4>
                        <h4>2). <a href="https://www.django-cms.org/en/">Django CMS</a></h4>
                        <h4>3). <a href="https://www.javatpoint.com/django-database-connectitvity">Djago Database</a></h4>
                        <h4>4). <a href="https://www.geeksforgeeks.org/how-to-create-an-app-in-django/">Django App</a></h4>
                        <h4>5). <a href="https://www.javatpoint.com/django-model">Django Model</a></h4>
                </div>
    </div>
  </div>
  <div class="container">
    <div class="row row-content">
       <div class="col-12 card">
                    <h2>Some Important Sources For HTML</h2>
                        <h4>1). <a href="https://en.wikipedia.org/wiki/HTML">About HTML</a></h4>
                        <h4>2). <a href="https://developer.mozilla.org/en-US/docs/Web/HTML/Element">HTML Elements</a></h4>
                        <h4>3). <a href="https://www.javatpoint.com/html-form">HTML Forms</a></h4>
                        <h4>4). <a href="https://www.geeksforgeeks.org/html-lists/">HTML List</a></h4>
                        <h4>5). <a href="http://www.w3.org/TR/NOTE-HTMLComponents">HTML Components</a></h4>
                </div>
    </div>
  </div>



    <?php include 'footer.php';

?>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  </body>
</html>