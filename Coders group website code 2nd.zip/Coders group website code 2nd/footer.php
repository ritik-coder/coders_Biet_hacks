<div class="container text-center bg-dark text-white">
<p class="mb-0">copyright@ our website is reserved and secured.</p>
</div>